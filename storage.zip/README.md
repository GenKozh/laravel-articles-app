# laravel-articles-app
Simple CRUD application on Laravel/mySQL
