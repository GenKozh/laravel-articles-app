<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-8 offset-md-2">
            <h1><?php echo e('Details page'); ?> </h1>
            <hr/>
                <?php echo Form::model($article,['method'=>'put']); ?>

            <div class="form-group row ">
                <?php echo Form::label("name","Author:",["class"=>"col-form-label col-md-3 col-lg-2"]); ?>

                <div class="col-md-8">
                    <?php echo Form::text("name",null,["class"=>"form-control".($errors->has('name')?" is-invalid":""),"autofocus",'placeholder'=>'Name', 'disabled' => 'disabled']); ?>

                </div>
            </div>
            <div class="form-group row ">
                <?php echo Form::label("title","Title:",["class"=>"col-form-label col-md-3 col-lg-2"]); ?>

                <div class="col-md-8">
                    <?php echo Form::text("title",null,["class"=>"form-control".($errors->has('title')?" is-invalid":""),"autofocus",'placeholder'=>'Title', 'disabled' => 'disabled']); ?>

                </div>
            </div>
            <div class="form-group row ">
                <?php echo Form::label("text","Text:",["class"=>"col-form-label col-md-3 col-lg-2"]); ?>

                <div class="col-md-8">
                    <?php echo Form::textarea("text", null, ["class"=>"form-control".($errors->has('text')?" is-invalid":""), 'rows' => 12, 'cols' => 54, 'style' => 'resize:none', 'placeholder'=>'Article text', 'disabled' => 'disabled']); ?>

                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-4 offset-md-2">
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-info">
                        Overview Page</a>
                </div>
                <div class="col-md-5 offset-md-1">
                    <a href="<?php echo e(url('/update/'.$article->id)); ?>" class="btn btn-danger">
                        Edit Page</a>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>