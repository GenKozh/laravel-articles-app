<?php $__env->startSection('css'); ?>
    <style>
        .form-group.required label:after {
            content: " *";
            color: red;
            font-weight: bold;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" >
        <div class="col-md-8 offset-md-2">
            <h1><?php echo e(isset($article)?'Edit page':'New Article'); ?> </h1>
            <hr/>
            <?php if(isset($article)): ?>
                <?php echo Form::model($article,['method'=>'put']); ?>

            <?php else: ?>
                <?php echo Form::open(); ?>

            <?php endif; ?>
            <div class="form-group row required" >
                <?php echo Form::label("name","Author:",["class"=>"col-form-label col-md-3 col-lg-2"]); ?>

                <div class="col-md-8" oninput="setValues('<?php echo e($article->id); ?>')">
                    <?php echo Form::text("name",null,["class"=>"form-control".($errors->has('name')?" is-invalid":""),'placeholder'=>'Name', 'id'=>'author']); ?>

                    <?php echo $errors->first('name','<span class="invalid-feedback">:message</span>'); ?>

                </div>
            </div>
            <div class="form-group row required">
                <?php echo Form::label("title","Title",["class"=>"col-form-label col-md-3 col-lg-2"]); ?>

                <div class="col-md-8" onchange="setValues('<?php echo e($article->id); ?>')">
                    <?php echo Form::text("title",null,["class"=>"form-control".($errors->has('title')?" is-invalid":""),'placeholder'=>'Title', 'id'=>'title']); ?>

                </div>
            </div>
            <div class="form-group row required">
                <?php echo Form::label("text","Text",["class"=>"col-form-label col-md-3 col-lg-2"]); ?>

                <div class="col-md-8" onchange="setValues('<?php echo e($article->id); ?>')">
                    <?php echo Form::textarea("text", null, ["class"=>"form-control".($errors->has('text')?" is-invalid":""), 'rows' => 12, 'cols' => 54, 'style' => 'resize:none', 'placeholder'=>'Article text', 'id'=>'text']); ?>

                    <?php echo $errors->first('text','<span class="invalid-feedback">:message</span>'); ?>

                </div>
            </div>
            <div class="form-group row">
                <div class="col-md-4 offset-md-2">
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-info">
                        Overview Page</a>
                    <a href="<?php echo e(url('/details/'.$article->id)); ?>" class="btn btn-danger">
                        Details Page</a>
                </div>
                <div class="col-md-4">
                <?php echo Form::button("Discard changes",["type" => "reset","class"=>"btn
                btn-primary"]); ?>

                    <!-- <a href="<?php echo e(url('/details/'.$article->id)); ?>" class="btn btn-warning">
                    Discard changes</a> -->
                    <?php echo Form::button("Save",["type" => "submit","class"=>"btn
                btn-primary"]); ?>


                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
        <script>
            getValues('<?php echo e($article->id); ?>');
        </script>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>